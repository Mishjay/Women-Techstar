document.addEventListener('DOMContentLoaded', function() {
    // Function to get advice from the API
    function getAdvice() {
        fetch('https://api.adviceslip.com/advice')
            .then(response => response.json())
            .then(data => {
                // Display the advice in the message box
                document.getElementById('messageText').textContent = 'Legal Advice: ' + data.slip.advice;
                document.getElementById('messageBox').classList.remove('hidden');

                // Optional: Hide the advice after a few seconds 
                setTimeout(function() {
                    document.getElementById('messageBox').classList.add('hidden');
                }, 2000);
            })
            .catch(error => {
                console.error('Error fetching advice:', error);
            });
    }

    // Event listener for the "Get Advice" button
    document.getElementById('getAdviceBtn').addEventListener('click', function() {
        getAdvice();
    });
});